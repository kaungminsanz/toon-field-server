Register ToonFieldRoom in your existing server entrypoint (usually src/index.ts or src/app.config.ts).
For current Colyseus server templates, add:
  import { ToonFieldRoom } from "./rooms/ToonFieldRoom";
and register room name "toon_field" using your template's defineRoom/room registration syntax.
See current official setup: https://docs.colyseus.io/recipes/setup-server-from-scratch-typescript
