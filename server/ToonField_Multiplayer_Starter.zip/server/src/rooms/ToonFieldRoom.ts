import { Room, Client } from "colyseus";
import { schema, t } from "@colyseus/schema";

const Player = schema({
  x: t.number().default(0),
  y: t.number().default(0),
  z: t.number().default(0),
  yaw: t.number().default(0),
  name: t.string().default("Guest"),
}, "Player");

const State = schema({ players: t.map(Player) }, "ToonFieldState");

export class ToonFieldRoom extends Room {
  state = new State();

  maxClients = 30;

  onJoin(client: Client, options: { name?: string }) {
    const p = new Player();
    p.name = String(options?.name || "Guest").slice(0, 18);
    p.x = Math.random() * 8 - 4;
    p.z = Math.random() * 8 - 4;
    this.state.players.set(client.sessionId, p);
  }

  onCreate() {
    this.onMessage("move", (client, data: any) => {
      const p = this.state.players.get(client.sessionId);
      if (!p || !data) return;
      // Server-side bounds and validation
      p.x = Number.isFinite(data.x) ? Math.max(-590, Math.min(590, data.x)) : p.x;
      p.y = Number.isFinite(data.y) ? Math.max(0, Math.min(20, data.y)) : p.y;
      p.z = Number.isFinite(data.z) ? Math.max(-590, Math.min(590, data.z)) : p.z;
      p.yaw = Number.isFinite(data.yaw) ? data.yaw : p.yaw;
      if (typeof data.name === "string") p.name = data.name.slice(0, 18);
    });
  }

  onLeave(client: Client) {
    this.state.players.delete(client.sessionId);
  }
}
