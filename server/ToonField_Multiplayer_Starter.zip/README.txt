TOON FIELD MULTIPLAYER PATCH (starter)

Files:
- index.html: your original Toon Field game with a basic client multiplayer patch.
- server/src/rooms/ToonFieldRoom.ts: room state and movement handler (30 player cap).

IMPORTANT:
1) Copy server/src/rooms/ToonFieldRoom.ts into your Codespace server at src/rooms/.
2) Register the room name "toon_field" in your server's existing room registry. Your server template may use src/index.ts or src/app.config.ts; see README-REGISTER.txt.
3) Replace your game's index.html with this patched index.html (keep a backup first).
4) Ensure Codespaces port 2567 is Public and server is running.
5) Reload game twice in two browser tabs/devices to test players.

This initial patch synchronizes position, height, facing, and display name. Rideable visuals/animations are not networked yet.
The game page uses @colyseus/sdk from esm.sh; browser internet access is needed.
